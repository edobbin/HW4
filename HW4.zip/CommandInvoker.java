public class CommandInvoker {
    
    static void executeCommand(Command command) {
        command.execute();
    }
}
