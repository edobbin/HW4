/**
 * MenuItem
 */
interface iMenuItem {
    int getNum();
    String getName();
    double getPrice();
    
}