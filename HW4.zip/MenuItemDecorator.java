public interface MenuItemDecorator {
    String getDescription();
    double getPrice();
}
